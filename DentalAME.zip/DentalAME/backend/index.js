const express = require("express");
const cors = require("cors");
const path = require("path");
const routes = require("./routes");

const app = express();
app.use(cors());
app.use(express.json());

// Health check
app.get("/", (_req, res) => res.json({ ok: true, name: "DentalAME API" }));

// API routes
app.use("/api", routes);

// Serve frontend (optional, when opened via Node)
app.use("/app", express.static(path.join(__dirname, "..", "frontend")));

const PORT = 3000;
app.listen(PORT, () => console.log(`✅ DentalAME API escuchando en http://localhost:${PORT}`));
