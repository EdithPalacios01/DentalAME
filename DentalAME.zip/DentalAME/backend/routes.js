const express = require("express");
const router = express.Router();
const pool = require("./db");
const bcrypt = require("bcryptjs");

// ============================================================
// AUTH
// ============================================================
router.post("/register", async (req, res) => {
  const { name, email, password, role } = req.body;
  try {
    const [rows] = await pool.query("SELECT * FROM users WHERE email=?", [email]);
    if (rows.length > 0) return res.status(400).json({ error: "El correo ya existe" });

    const hash = await bcrypt.hash(password, 10);
    await pool.query(
      "INSERT INTO users (name, email, password, role) VALUES (?, ?, ?, ?)",
      [name, email, hash, role || "paciente"]
    );

    res.json({ ok: true, message: "Usuario registrado correctamente" });
  } catch (err) {
    console.error("❌ Error en /register:", err);
    res.status(500).json({ error: err.message });
  }
});

router.post("/login", async (req, res) => {
  const { email, password } = req.body;
  try {
    const [rows] = await pool.query("SELECT * FROM users WHERE email=?", [email]);
    if (rows.length === 0) return res.status(400).json({ error: "Usuario no encontrado" });

    const user = rows[0];
    let valid = false;

    // Permitir contraseñas en texto plano para datos de ejemplo (si no comienzan con $2)
    if (user.password && user.password.startsWith("$2")) {
      valid = await bcrypt.compare(password, user.password);
    } else {
      valid = password === user.password;
    }

    if (!valid) return res.status(400).json({ error: "Contraseña incorrecta" });

    const safeUser = { id: user.id, name: user.name, email: user.email, role: user.role };
    res.json({ ok: true, user: safeUser });
  } catch (err) {
    console.error("❌ Error en /login:", err);
    res.status(500).json({ error: err.message });
  }
});

// ============================================================
// ADMIN: TABLAS DISPONIBLES
// ============================================================
router.get("/admin/tables", async (_req, res) => {
  res.json([
    "users",
    "secretarias",
    "doctores",
    "pacientes",
    "reservas",
    "pagos",
    "horarios",
    "consultorios",
  ]);
});

// ============================================================
/* ADMIN: LISTAR REGISTROS (enriquecidos cuando aplica) */
// ============================================================
router.get("/admin/table/:name", async (req, res) => {
  try {
    const table = req.params.name;
    let query;

    switch (table) {
      case "users":
        query = "SELECT id, name, email, role FROM users ORDER BY id DESC";
        break;

      case "secretarias":
        query = `
          SELECT s.id, s.nombre, s.apellidos, s.ci, s.celular, u.email, u.role
          FROM secretarias s
          INNER JOIN users u ON s.user_id = u.id
          ORDER BY s.id DESC
        `;
        break;

      case "doctores":
        query = `
          SELECT d.id, u.name AS nombre, u.email, d.telefono, d.licencia_medica, d.especialidad
          FROM doctores d
          INNER JOIN users u ON d.user_id = u.id
          ORDER BY d.id DESC
        `;
        break;

      case "pacientes":
        query = `
          SELECT p.id, COALESCE(p.nombre, u.name) AS nombre, u.email, p.ci, p.nro_seguro, p.fecha_nacimiento
          FROM pacientes p
          INNER JOIN users u ON p.user_id = u.id
          ORDER BY p.id DESC
        `;
        break;

      case "reservas":
        query = `
          SELECT 
            r.id,
            pa.nombre AS paciente,
            u_doctor.name AS doctor,
            d.especialidad,
            c.nombre AS consultorio,
            DATE_FORMAT(r.fecha, '%Y-%m-%d') AS fecha,
            TIME_FORMAT(r.hora, '%H:%i') AS hora,
            r.estado
          FROM reservas r
          INNER JOIN pacientes pa   ON r.paciente_id   = pa.id
          INNER JOIN doctores d     ON r.doctor_id     = d.id
          INNER JOIN users u_doctor ON d.user_id       = u_doctor.id
          INNER JOIN consultorios c ON r.consultorio_id = c.id
          ORDER BY r.fecha DESC, r.hora ASC
        `;
        break;

      case "pagos":
        query = `
          SELECT 
            p.id,
            pa.nombre AS paciente,
            u_d.name AS doctor,
            c.nombre AS consultorio,
            DATE_FORMAT(p.fecha_pago, '%Y-%m-%d') AS fecha_pago,
            p.monto,
            p.descripcion
          FROM pagos p
          INNER JOIN pacientes pa   ON p.paciente_id   = pa.id
          INNER JOIN doctores d     ON p.doctor_id     = d.id
          INNER JOIN users u_d      ON d.user_id       = u_d.id
          INNER JOIN consultorios c ON p.consultorio_id = c.id
          ORDER BY p.fecha_pago DESC
        `;
        break;

      case "horarios":
        query = `
          SELECT 
            h.id,
            u.name AS doctor,
            c.nombre AS consultorio,
            h.especialidad,
            h.dia,
            TIME_FORMAT(h.hora_inicio, '%H:%i') AS hora_inicio,
            TIME_FORMAT(h.hora_fin, '%H:%i') AS hora_fin
          FROM horarios h
          INNER JOIN doctores d ON h.doctor_id = d.id
          INNER JOIN users u ON d.user_id = u.id
          INNER JOIN consultorios c ON h.consultorio_id = c.id
          ORDER BY FIELD(h.dia,'LUNES','MARTES','MIERCOLES','JUEVES','VIERNES','SABADO','DOMINGO'), h.hora_inicio
        `;
        break;

      case "consultorios":
        query = "SELECT id, nombre, ubicacion FROM consultorios ORDER BY id DESC";
        break;

      default:
        return res.status(400).json({ error: "Tabla no reconocida" });
    }

    const [rows] = await pool.query(query);
    res.json(rows);
  } catch (err) {
    console.error("❌ Error al listar tabla:", err);
    res.status(500).json({ error: err.message });
  }
});

// ============================================================
// ADMIN: CREAR NUEVOS REGISTROS
// ============================================================
router.post("/admin/:table", async (req, res) => {
  const { table } = req.params;
  const data = req.body;

  try {
    switch (table) {
      case "users": {
        const hash = await bcrypt.hash(data.password || "123456", 10);
        await pool.query(
          "INSERT INTO users (name, email, password, role) VALUES (?, ?, ?, ?)",
          [data.name, data.email, hash, data.role]
        );
        break;
      }

      case "consultorios": {
        await pool.query(
          "INSERT INTO consultorios (nombre, ubicacion) VALUES (?, ?)",
          [data.nombre, data.ubicacion || null]
        );
        break;
      }

      case "horarios": {
        await pool.query(
          "INSERT INTO horarios (doctor_id, consultorio_id, especialidad, dia, hora_inicio, hora_fin) VALUES (?, ?, ?, ?, ?, ?)",
          [data.doctor_id, data.consultorio_id, data.especialidad, data.dia, data.hora_inicio, data.hora_fin]
        );
        break;
      }

      case "pagos": {
        await pool.query(
          "INSERT INTO pagos (paciente_id, doctor_id, consultorio_id, fecha_pago, monto, descripcion) VALUES (?, ?, ?, ?, ?, ?)",
          [data.paciente_id, data.doctor_id, data.consultorio_id, data.fecha_pago, data.monto, data.descripcion || null]
        );
        break;
      }

      default:
        await pool.query(`INSERT INTO \`${table}\` SET ?`, [data]);
    }

    res.json({ ok: true, message: "Registro creado correctamente" });
  } catch (err) {
    console.error("❌ Error creando registro:", err);
    res.status(500).json({ error: err.message });
  }
});

// ============================================================
// ADMIN: EDITAR / ELIMINAR (genérico por simplicidad)
// ============================================================
router.put("/admin/table/:table/:id", async (req, res) => {
  try {
    const { table, id } = req.params;
    const data = req.body;
    await pool.query(`UPDATE \`${table}\` SET ? WHERE id=?`, [data, id]);
    res.json({ ok: true });
  } catch (err) {
    console.error("❌ Error al actualizar:", err);
    res.status(500).json({ error: err.message });
  }
});

router.delete("/admin/table/:table/:id", async (req, res) => {
  try {
    const { table, id } = req.params;
    await pool.query(`DELETE FROM \`${table}\` WHERE id=?`, [id]);
    res.json({ ok: true });
  } catch (err) {
    console.error("❌ Error al eliminar:", err);
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
