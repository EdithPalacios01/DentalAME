
-- Crear base y usarla
CREATE DATABASE IF NOT EXISTS dentalame CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE dentalame;

-- Tabla usuarios
DROP TABLE IF EXISTS users;
CREATE TABLE users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  email VARCHAR(120) NOT NULL UNIQUE,
  password VARCHAR(255) NOT NULL,
  role ENUM('admin','secretaria','doctor','paciente') NOT NULL DEFAULT 'paciente',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tabla secretarias
DROP TABLE IF EXISTS secretarias;
CREATE TABLE secretarias (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  nombre VARCHAR(100),
  apellidos VARCHAR(100),
  ci VARCHAR(30),
  celular VARCHAR(30),
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Tabla doctores
DROP TABLE IF EXISTS doctores;
CREATE TABLE doctores (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  telefono VARCHAR(30),
  licencia_medica VARCHAR(100),
  especialidad VARCHAR(100),
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Tabla pacientes
DROP TABLE IF EXISTS pacientes;
CREATE TABLE pacientes (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  nombre VARCHAR(100),
  ci VARCHAR(30),
  nro_seguro VARCHAR(50),
  fecha_nacimiento DATE,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Tabla consultorios
DROP TABLE IF EXISTS consultorios;
CREATE TABLE consultorios (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nombre VARCHAR(100) NOT NULL,
  ubicacion VARCHAR(255) NULL
);

-- Tabla horarios
DROP TABLE IF EXISTS horarios;
CREATE TABLE horarios (
  id INT AUTO_INCREMENT PRIMARY KEY,
  doctor_id INT NOT NULL,
  consultorio_id INT NOT NULL,
  especialidad VARCHAR(100) NOT NULL,
  dia ENUM('LUNES','MARTES','MIERCOLES','JUEVES','VIERNES','SABADO','DOMINGO') NOT NULL,
  hora_inicio TIME NOT NULL,
  hora_fin TIME NOT NULL,
  FOREIGN KEY (doctor_id) REFERENCES doctores(id) ON DELETE CASCADE,
  FOREIGN KEY (consultorio_id) REFERENCES consultorios(id) ON DELETE CASCADE
);

-- Tabla reservas
DROP TABLE IF EXISTS reservas;
CREATE TABLE reservas (
  id INT AUTO_INCREMENT PRIMARY KEY,
  paciente_id INT NOT NULL,
  doctor_id INT NOT NULL,
  consultorio_id INT NOT NULL,
  fecha DATE NOT NULL,
  hora TIME NOT NULL,
  estado ENUM('pendiente','confirmada','cancelada') DEFAULT 'pendiente',
  FOREIGN KEY (paciente_id) REFERENCES pacientes(id) ON DELETE CASCADE,
  FOREIGN KEY (doctor_id) REFERENCES doctores(id) ON DELETE CASCADE,
  FOREIGN KEY (consultorio_id) REFERENCES consultorios(id) ON DELETE CASCADE
);

-- Tabla pagos
DROP TABLE IF EXISTS pagos;
CREATE TABLE pagos (
  id INT AUTO_INCREMENT PRIMARY KEY,
  paciente_id INT NOT NULL,
  doctor_id INT NOT NULL,
  consultorio_id INT NOT NULL,
  fecha_pago DATE NOT NULL,
  monto DECIMAL(10,2) NOT NULL,
  descripcion TEXT NULL,
  FOREIGN KEY (paciente_id) REFERENCES pacientes(id) ON DELETE CASCADE,
  FOREIGN KEY (doctor_id) REFERENCES doctores(id) ON DELETE CASCADE,
  FOREIGN KEY (consultorio_id) REFERENCES consultorios(id) ON DELETE CASCADE
);

-- ==================
-- Datos de ejemplo
-- ==================
INSERT INTO users (name, email, password, role) VALUES
('Admin DentalAME','admin@dentalame.com','admin123','admin'),
('Dr. Juan Pérez','juan@dentalame.com','doctor123','doctor'),
('Paciente Demo','paciente@dentalame.com','paciente123','paciente'),
('Secretaria Demo','sec@dentalame.com','secretaria123','secretaria');

INSERT INTO doctores (user_id, telefono, licencia_medica, especialidad) VALUES
(2,'+52 555-000-111','LIC-DEM-001','Odontología General');

INSERT INTO pacientes (user_id, nombre, ci, nro_seguro, fecha_nacimiento) VALUES
(3,'Paciente Demo','12345678','SEG-001','1995-06-15');

INSERT INTO secretarias (user_id, nombre, apellidos, ci, celular) VALUES
(4,'Ana','Suárez','87654321','+52 555-000-222');

INSERT INTO consultorios (nombre, ubicacion) VALUES
('Consultorio Principal DentalAME','Av. Siempre Viva 123, Centro');

INSERT INTO horarios (doctor_id, consultorio_id, especialidad, dia, hora_inicio, hora_fin) VALUES
(1,1,'Odontología General','LUNES','09:00:00','13:00:00'),
(1,1,'Odontología General','MIERCOLES','15:00:00','19:00:00');

INSERT INTO reservas (paciente_id, doctor_id, consultorio_id, fecha, hora, estado) VALUES
(1,1,1,'2025-08-15','10:30:00','confirmada');

INSERT INTO pagos (paciente_id, doctor_id, consultorio_id, fecha_pago, monto, descripcion) VALUES
(1,1,1,'2025-08-01', 120.00, 'Limpieza dental y revisión');
