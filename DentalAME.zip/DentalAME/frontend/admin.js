const API = "http://localhost:3000/api";

/* =========================
   VALIDAR ADMIN
========================= */
(function enforceAdmin() {
  const raw = localStorage.getItem("user");
  if (!raw) return (location.href = "index.html");
  const user = JSON.parse(raw);
  if (user.role !== "admin") location.href = "dashboard.html";
})();

/* =========================
   LOGOUT
========================= */
document.getElementById("logoutBtn").addEventListener("click", () => {
  localStorage.removeItem("user");
  location.href = "index.html";
});

/* =========================
   HELPERS
========================= */
function normalizeDateForInput(v) {
  if (!v) return "";
  if (/^\d{4}-\d{2}-\d{2}$/.test(v)) return v;
  const d = new Date(v);
  return isNaN(d) ? "" : d.toISOString().slice(0, 10);
}

async function fetchJSON(url, opts = {}) {
  const res = await fetch(url, opts);
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  return res.json();
}

/* =========================
   MENÚ DE TABLAS
========================= */
async function loadTablesMenu() {
  const ul = document.getElementById("tablesMenu");
  ul.innerHTML = "";
  try {
    const tables = await fetchJSON(`${API}/admin/tables`);
    tables.forEach((t, i) => {
      const li = document.createElement("li");
      const btn = document.createElement("button");
      btn.textContent = t;
      btn.className = "btn btn-outline-light w-100 mb-1";
      btn.addEventListener("click", () => onSelectTable(t, btn));
      if (i === 0) setTimeout(() => btn.click(), 0);
      li.appendChild(btn);
      ul.appendChild(li);
    });
  } catch (err) {
    console.error("❌ Error cargando tablas:", err);
  }
}

/* =========================
   LISTAR REGISTROS
========================= */
async function onSelectTable(table, btn) {
  document.querySelectorAll("#tablesMenu button").forEach(b => b.classList.remove("active"));
  btn.classList.add("active");

  const content = document.getElementById("content");
  const reportContainer = document.getElementById("reportBlock");
  if (reportContainer) reportContainer.innerHTML = "";

  content.innerHTML = `<h3>Tabla: <code>${table}</code></h3><p>Cargando registros...</p>`;

  try {
    const rows = await fetchJSON(`${API}/admin/table/${table}`);

    if (!rows.length) {
      content.innerHTML = `
        <h3>Tabla: <code>${table}</code></h3>
        <button class="btn btn-primary mb-3" onclick="newRow('${table}')">➕ Nuevo</button>
        <p>No hay registros.</p>`;
      return;
    }

    const headers = Object.keys(rows[0]);
    let html = `
      <h3>Tabla: <code>${table}</code></h3>
      <button class="btn btn-primary mb-3" onclick="newRow('${table}')">➕ Nuevo</button>
      <table class="table table-striped table-bordered display nowrap" style="width:100%">
        <thead class="table-dark">
          <tr>${headers.map(h => `<th>${h}</th>`).join("")}<th>Acciones</th></tr>
        </thead>
        <tbody>`;

    rows.forEach(r => {
      html += `
        <tr>
          ${headers.map(h => `<td>${r[h]}</td>`).join("")}
          <td class="text-center" style="white-space:nowrap;">
            <div class="btn-group">
              
              <button class="btn btn-outline-success btn-sm" onclick="editRow('${table}', ${r.id})">🟢 Editar</button>
              <button class="btn btn-outline-danger btn-sm" onclick="deleteRow('${table}', ${r.id})">🔴 Eliminar</button>
              ${table === "pagos" ? `<button class="btn btn-outline-info btn-sm" onclick="generatePaymentReceipt(${r.id})">🧾 Imprimir</button>` : ""}
            </div>
          </td>
        </tr>`;
    });

    html += "</tbody></table>";
    content.innerHTML = html;

    // DataTables
    if ($.fn.DataTable.isDataTable(".table")) $(".table").DataTable().destroy();
    $(".table").DataTable({
      responsive: true,
      language: {
        search: "🔍 Buscar:",
        lengthMenu: "Mostrar _MENU_ registros",
        info: "Mostrando _START_ a _END_ de _TOTAL_ registros",
        paginate: { first: "Primero", last: "Último", next: "▶", previous: "◀" },
        zeroRecords: "No se encontraron coincidencias"
      },
      pageLength: 5
    });

    // Bloque de reportes solo para reservas
    const reportBlock = document.getElementById("reportBlock");
    if (table === "reservas" && reportBlock) {
      const today = new Date().toISOString().slice(0,10);
      reportBlock.innerHTML = `
        <div class="card shadow-sm mb-3">
          <div class="card-body">
            <h5 class="card-title text-primary">📄 Reporte General de Reservas</h5>
            <p class="text-muted mb-3">Exporta todas las reservas registradas en PDF.</p>
            <button class="btn btn-success me-2" onclick="generateReservationsReport()">
              <i class="bi bi-printer"></i> Generar reporte general
            </button>
          </div>
        </div>
        <div class="card shadow-sm">
          <div class="card-body">
            <h5 class="card-title text-primary">📆 Reporte por Fechas</h5>
            <p class="text-muted">Selecciona un rango de fechas para generar un reporte personalizado.</p>
            <div class="row g-3 align-items-center">
              <div class="col-auto">
                <label for="fechaInicio" class="col-form-label fw-bold">Inicio:</label>
              </div>
              <div class="col-auto">
                <input type="date" id="fechaInicio" class="form-control" value="${today}">
              </div>
              <div class="col-auto">
                <label for="fechaFin" class="col-form-label fw-bold">Fin:</label>
              </div>
              <div class="col-auto">
                <input type="date" id="fechaFin" class="form-control" value="${today}">
              </div>
              <div class="col-auto">
                <button class="btn btn-primary" onclick="generateReservationsReportByDate()">
                  <i class="bi bi-calendar-check"></i> Generar
                </button>
              </div>
            </div>
          </div>
        </div>`;
    }
  } catch (err) {
    console.error("❌ Error al cargar tabla:", err);
    content.innerHTML = `<p>Error cargando registros.</p>`;
  }
}

/* =========================
   NUEVO REGISTRO
========================= */
async function newRow(table) {
  const content = document.getElementById("content");
  let fieldsHTML = "";

  switch (table) {
    case "users":
      fieldsHTML = `
        <input class="form-control mb-2" name="name" placeholder="Nombre completo" required>
        <input class="form-control mb-2" name="email" type="email" placeholder="Correo electrónico" required>
        <input class="form-control mb-2" name="password" type="password" placeholder="Contraseña" required>
        <select name="role" class="form-select mb-3" required>
          <option value="">Selecciona un rol</option>
          <option value="admin">Administrador</option>
          <option value="secretaria">Secretaria</option>
          <option value="doctor">Doctor</option>
          <option value="paciente">Paciente</option>
        </select>`;
      break;

    case "consultorios":
      fieldsHTML = `
        <input class="form-control mb-2" name="nombre" placeholder="Nombre del consultorio" required>
        <input class="form-control mb-2" name="ubicacion" placeholder="Ubicación o referencia">`;
      break;

    case "reservas": {
      const [pacientes, doctores, consultorios] = await Promise.all([
        fetchJSON(`${API}/admin/table/pacientes`),
        fetchJSON(`${API}/admin/table/doctores`),
        fetchJSON(`${API}/admin/table/consultorios`)
      ]);
      fieldsHTML = `
        <label class="fw-bold">Paciente</label>
        <select name="paciente_id" class="form-select mb-2" required>
          ${pacientes.map(p => `<option value="${p.id}">${p.nombre}</option>`).join("")}
        </select>
        <label class="fw-bold">Doctor</label>
        <select name="doctor_id" class="form-select mb-2" required>
          ${doctores.map(d => `<option value="${d.id}">${d.nombre}</option>`).join("")}
        </select>
        <label class="fw-bold">Consultorio</label>
        <select name="consultorio_id" class="form-select mb-2" required>
          ${consultorios.map(c => `<option value="${c.id}">${c.nombre}</option>`).join("")}
        </select>
        <label class="fw-bold">Fecha</label>
        <input class="form-control mb-2" type="date" name="fecha" required>
        <label class="fw-bold">Hora</label>
        <input class="form-control mb-2" type="time" name="hora" required>
        <label class="fw-bold">Estado</label>
        <select class="form-select mb-3" name="estado">
          <option value="pendiente">Pendiente</option>
          <option value="confirmada">Confirmada</option>
          <option value="cancelada">Cancelada</option>
        </select>`;
      break;
    }

    case "pagos": {
      const [pacientes, doctores, consultorios] = await Promise.all([
        fetchJSON(`${API}/admin/table/pacientes`),
        fetchJSON(`${API}/admin/table/doctores`),
        fetchJSON(`${API}/admin/table/consultorios`)
      ]);
      fieldsHTML = `
        <label class="fw-bold">Paciente</label>
        <select name="paciente_id" class="form-select mb-2" required>
          ${pacientes.map(p => `<option value="${p.id}">${p.nombre}</option>`).join("")}
        </select>
        <label class="fw-bold">Doctor</label>
        <select name="doctor_id" class="form-select mb-2" required>
          ${doctores.map(d => `<option value="${d.id}">${d.nombre}</option>`).join("")}
        </select>
        <label class="fw-bold">Consultorio</label>
        <select name="consultorio_id" class="form-select mb-2" required>
          ${consultorios.map(c => `<option value="${c.id}">${c.nombre}</option>`).join("")}
        </select>
        <label class="fw-bold">Fecha de pago</label>
        <input class="form-control mb-2" name="fecha_pago" type="date" required>
        <input class="form-control mb-2" name="monto" type="number" step="0.01" placeholder="Monto" required>
        <textarea class="form-control mb-3" name="descripcion" placeholder="Descripción (opcional)" rows="3"></textarea>`;
      break;
    }

    case "horarios": {
      const [doctores, consultorios] = await Promise.all([
        fetchJSON(`${API}/admin/table/doctores`),
        fetchJSON(`${API}/admin/table/consultorios`)
      ]);
      fieldsHTML = `
        <label class="fw-bold">Doctor</label>
        <select name="doctor_id" class="form-select mb-2" required>
          ${doctores.map(d => `<option value="${d.id}">${d.nombre}</option>`).join("")}
        </select>
        <label class="fw-bold">Consultorio</label>
        <select name="consultorio_id" class="form-select mb-2" required>
          ${consultorios.map(c => `<option value="${c.id}">${c.nombre}</option>`).join("")}
        </select>
        <input class="form-control mb-2" name="especialidad" placeholder="Especialidad" required>
        <label class="fw-bold">Día</label>
        <select name="dia" class="form-select mb-2" required>
          <option value="">Selecciona un día</option>
          <option value="LUNES">Lunes</option>
          <option value="MARTES">Martes</option>
          <option value="MIERCOLES">Miércoles</option>
          <option value="JUEVES">Jueves</option>
          <option value="VIERNES">Viernes</option>
          <option value="SABADO">Sábado</option>
          <option value="DOMINGO">Domingo</option>
        </select>
        <label class="fw-bold">Hora inicio</label>
        <input type="time" name="hora_inicio" class="form-control mb-2" required>
        <label class="fw-bold">Hora fin</label>
        <input type="time" name="hora_fin" class="form-control mb-2" required>`;
      break;
    }

    case "pacientes":
      fieldsHTML = `
        <input class="form-control mb-2" name="user_id" type="number" placeholder="ID de usuario (paciente)" required>
        <input class="form-control mb-2" name="nombre" placeholder="Nombre" required>
        <input class="form-control mb-2" name="ci" placeholder="CI" required>
        <input class="form-control mb-2" name="nro_seguro" placeholder="Número de Seguro" required>
        <input class="form-control mb-2" name="fecha_nacimiento" type="date" required>`;
      break;

    case "doctores":
      fieldsHTML = `
        <input class="form-control mb-2" name="user_id" type="number" placeholder="ID de usuario (doctor)" required>
        <input class="form-control mb-2" name="telefono" placeholder="Teléfono" required>
        <input class="form-control mb-2" name="licencia_medica" placeholder="Licencia Médica" required>
        <input class="form-control mb-2" name="especialidad" placeholder="Especialidad" required>`;
      break;

    case "secretarias":
      fieldsHTML = `
        <input class="form-control mb-2" name="user_id" type="number" placeholder="ID de usuario (secretaria)" required>
        <input class="form-control mb-2" name="nombre" placeholder="Nombre" required>
        <input class="form-control mb-2" name="apellidos" placeholder="Apellidos" required>
        <input class="form-control mb-2" name="ci" placeholder="CI" required>
        <input class="form-control mb-2" name="celular" placeholder="Celular" required>`;
      break;

    default:
      fieldsHTML = `<p class="text-muted">⚠️ Esta tabla aún no tiene formulario definido.</p>`;
  }

  content.innerHTML = `
    <h3>Nuevo registro en <code>${table}</code></h3>
    <form id="recordForm">${fieldsHTML}
      <button type="submit" class="btn btn-primary mt-2">Guardar</button>
      <button type="button" class="btn btn-secondary mt-2" onclick="onSelectTable('${table}', document.querySelector('#tablesMenu button.active'))">Cancelar</button>
    </form>`;

  document.getElementById("recordForm").addEventListener("submit", async e => {
    e.preventDefault();
    const data = Object.fromEntries(new FormData(e.target));
    try {
      await fetchJSON(`${API}/admin/${table}`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data)
      });
      onSelectTable(table, document.querySelector('#tablesMenu button.active'));
    } catch (err) {
      alert("❌ Error guardando registro: " + err.message);
    }
  });
}

/* =========================
   EDITAR / ELIMINAR / 
========================= */
async function editRow(table, id) {
  const rows = await fetchJSON(`${API}/admin/table/${table}`);
  const record = rows.find(r => r.id === id);
  if (!record) return alert("Registro no encontrado");

  const content = document.getElementById("content");

  if (table === "users") {
    content.innerHTML = `
      <h3>Editar usuario</h3>
      <form id="recordForm">
        <input class="form-control mb-2" name="name" value="${record.name || ""}" placeholder="Nombre">
        <input class="form-control mb-2" name="email" value="${record.email || ""}" placeholder="Email">
        <select name="role" class="form-select mb-2">
          <option ${record.role==="admin"?"selected":""} value="admin">Administrador</option>
          <option ${record.role==="secretaria"?"selected":""} value="secretaria">Secretaria</option>
          <option ${record.role==="doctor"?"selected":""} value="doctor">Doctor</option>
          <option ${record.role==="paciente"?"selected":""} value="paciente">Paciente</option>
        </select>
        <button type="submit" class="btn btn-primary mt-2">Guardar</button>
        <button type="button" class="btn btn-secondary mt-2" onclick="onSelectTable('${table}', document.querySelector('#tablesMenu button.active'))">Cancelar</button>
      </form>`;
  } else if (table === "consultorios") {
    content.innerHTML = `
      <h3>Editar consultorio</h3>
      <form id="recordForm">
        <input class="form-control mb-2" name="nombre" value="${record.nombre || ""}" placeholder="Nombre">
        <input class="form-control mb-2" name="ubicacion" value="${record.ubicacion || ""}" placeholder="Ubicación">
        <button type="submit" class="btn btn-primary mt-2">Guardar</button>
        <button type="button" class="btn btn-secondary mt-2" onclick="onSelectTable('${table}', document.querySelector('#tablesMenu button.active'))">Cancelar</button>
      </form>`;
  } else if (table === "pacientes") {
    content.innerHTML = `
      <h3>Editar paciente</h3>
      <form id="recordForm">
        <input class="form-control mb-2" name="nombre" value="${record.nombre || ""}" placeholder="Nombre">
        <input class="form-control mb-2" name="ci" value="${record.ci || ""}" placeholder="CI">
        <input class="form-control mb-2" name="nro_seguro" value="${record.nro_seguro || ""}" placeholder="Número de Seguro">
        <input class="form-control mb-2" name="fecha_nacimiento" type="date" value="${normalizeDateForInput(record.fecha_nacimiento)}">
        <button type="submit" class="btn btn-primary mt-2">Guardar</button>
        <button type="button" class="btn btn-secondary mt-2" onclick="onSelectTable('${table}', document.querySelector('#tablesMenu button.active'))">Cancelar</button>
      </form>`;
  } else if (table === "doctores") {
    content.innerHTML = `
      <h3>Editar doctor</h3>
      <form id="recordForm">
        <input class="form-control mb-2" name="telefono" value="${record.telefono || ""}" placeholder="Teléfono">
        <input class="form-control mb-2" name="licencia_medica" value="${record.licencia_medica || ""}" placeholder="Licencia Médica">
        <input class="form-control mb-2" name="especialidad" value="${record.especialidad || ""}" placeholder="Especialidad">
        <button type="submit" class="btn btn-primary mt-2">Guardar</button>
        <button type="button" class="btn btn-secondary mt-2" onclick="onSelectTable('${table}', document.querySelector('#tablesMenu button.active'))">Cancelar</button>
      </form>`;
  } else if (table === "secretarias") {
    content.innerHTML = `
      <h3>Editar secretaria</h3>
      <form id="recordForm">
        <input class="form-control mb-2" name="nombre" value="${record.nombre || ""}" placeholder="Nombre">
        <input class="form-control mb-2" name="apellidos" value="${record.apellidos || ""}" placeholder="Apellidos">
        <input class="form-control mb-2" name="ci" value="${record.ci || ""}" placeholder="CI">
        <input class="form-control mb-2" name="celular" value="${record.celular || ""}" placeholder="Celular">
        <button type="submit" class="btn btn-primary mt-2">Guardar</button>
        <button type="button" class="btn btn-secondary mt-2" onclick="onSelectTable('${table}', document.querySelector('#tablesMenu button.active'))">Cancelar</button>
      </form>`;
  } else if (table === "pagos") {
    const [pacientes, doctores, consultorios] = await Promise.all([
      fetchJSON(`${API}/admin/table/pacientes`),
      fetchJSON(`${API}/admin/table/doctores`),
      fetchJSON(`${API}/admin/table/consultorios`)
    ]);
    content.innerHTML = `
      <h3>Editar pago</h3>
      <form id="recordForm">
        <label class="fw-bold">Paciente</label>
        <select name="paciente_id" class="form-select mb-2" required>
          <option value="">-- Selecciona --</option>
          ${pacientes.map(p => `<option value="${p.id}">${p.nombre}</option>`).join("")}
        </select>
        <label class="fw-bold">Doctor</label>
        <select name="doctor_id" class="form-select mb-2" required>
          <option value="">-- Selecciona --</option>
          ${doctores.map(d => `<option value="${d.id}">${d.nombre}</option>`).join("")}
        </select>
        <label class="fw-bold">Consultorio</label>
        <select name="consultorio_id" class="form-select mb-2" required>
          <option value="">-- Selecciona --</option>
          ${consultorios.map(c => `<option value="${c.id}">${c.nombre}</option>`).join("")}
        </select>
        <input class="form-control mb-2" name="fecha_pago" type="date" value="${normalizeDateForInput(record.fecha_pago)}" required>
        <input class="form-control mb-2" name="monto" type="number" step="0.01" value="${record.monto || ""}" placeholder="Monto" required>
        <textarea class="form-control mb-2" name="descripcion" placeholder="Descripción">${record.descripcion || ""}</textarea>
        <button type="submit" class="btn btn-primary mt-2">Guardar</button>
        <button type="button" class="btn btn-secondary mt-2" onclick="onSelectTable('${table}', document.querySelector('#tablesMenu button.active'))">Cancelar</button>
      </form>`;
  } else if (table === "horarios") {
    const [doctores, consultorios] = await Promise.all([
      fetchJSON(`${API}/admin/table/doctores`),
      fetchJSON(`${API}/admin/table/consultorios`)
    ]);
    content.innerHTML = `
      <h3>Editar horario</h3>
      <form id="recordForm">
        <label class="fw-bold">Doctor</label>
        <select name="doctor_id" class="form-select mb-2" required>
          <option value="">-- Selecciona --</option>
          ${doctores.map(d => `<option value="${d.id}">${d.nombre}</option>`).join("")}
        </select>
        <label class="fw-bold">Consultorio</label>
        <select name="consultorio_id" class="form-select mb-2" required>
          <option value="">-- Selecciona --</option>
          ${consultorios.map(c => `<option value="${c.id}">${c.nombre}</option>`).join("")}
        </select>
        <input class="form-control mb-2" name="especialidad" value="${record.especialidad || ""}" placeholder="Especialidad" required>
        <label class="fw-bold">Día</label>
        <select name="dia" class="form-select mb-2" required>
          <option value="">Selecciona un día</option>
          ${["LUNES","MARTES","MIERCOLES","JUEVES","VIERNES","SABADO","DOMINGO"].map(d=>`
            <option ${record.dia===d ? "selected": ""} value="${d}">${d[0]+d.slice(1).toLowerCase()}</option>`).join("")}
        </select>
        <label class="fw-bold">Hora inicio</label>
        <input type="time" name="hora_inicio" class="form-control mb-2" required>
        <label class="fw-bold">Hora fin</label>
        <input type="time" name="hora_fin" class="form-control mb-2" required>
        <button type="submit" class="btn btn-primary mt-2">Guardar</button>
        <button type="button" class="btn btn-secondary mt-2" onclick="onSelectTable('${table}', document.querySelector('#tablesMenu button.active'))">Cancelar</button>
      </form>`;
  } else if (table === "reservas") {
    const [pacientes, doctores, consultorios] = await Promise.all([
      fetchJSON(`${API}/admin/table/pacientes`),
      fetchJSON(`${API}/admin/table/doctores`),
      fetchJSON(`${API}/admin/table/consultorios`)
    ]);
    content.innerHTML = `
      <h3>Editar reserva</h3>
      <form id="recordForm">
        <label class="fw-bold">Paciente</label>
        <select name="paciente_id" class="form-select mb-2" required>
          <option value="">-- Selecciona --</option>
          ${pacientes.map(p => `<option value="${p.id}">${p.nombre}</option>`).join("")}
        </select>
        <label class="fw-bold">Doctor</label>
        <select name="doctor_id" class="form-select mb-2" required>
          <option value="">-- Selecciona --</option>
          ${doctores.map(d => `<option value="${d.id}">${d.nombre}</option>`).join("")}
        </select>
        <label class="fw-bold">Consultorio</label>
        <select name="consultorio_id" class="form-select mb-2" required>
          <option value="">-- Selecciona --</option>
          ${consultorios.map(c => `<option value="${c.id}">${c.nombre}</option>`).join("")}
        </select>
        <input class="form-control mb-2" type="date" name="fecha" value="${normalizeDateForInput(record.fecha)}" required>
        <input class="form-control mb-2" type="time" name="hora" required>
        <select class="form-select mb-2" name="estado">
          ${["pendiente","confirmada","cancelada"].map(es=>`
            <option ${record.estado===es?"selected":""} value="${es}">${es[0].toUpperCase()+es.slice(1)}</option>`).join("")}
        </select>
        <button type="submit" class="btn btn-primary mt-2">Guardar</button>
        <button type="button" class="btn btn-secondary mt-2" onclick="onSelectTable('${table}', document.querySelector('#tablesMenu button.active'))">Cancelar</button>
      </form>`;
  } else {
    content.innerHTML = `
      <h3>Editar registro</h3>
      <form id="recordForm"><div id="fields"></div>
        <button type="submit" class="btn btn-primary mt-2">Guardar</button>
        <button type="button" class="btn btn-secondary mt-2" onclick="onSelectTable('${table}', document.querySelector('#tablesMenu button.active'))">Cancelar</button>
      </form>`;
    const fieldsDiv = document.getElementById("fields");
    for (let [key, value] of Object.entries(record)) {
      if (key === "id") continue;
      fieldsDiv.innerHTML += `
        <div class="mb-2">
          <label class="form-label">${key}</label>
          <input class="form-control" name="${key}" value="${value ?? ""}">
        </div>`;
    }
  }

  document.getElementById("recordForm").addEventListener("submit", async e => {
    e.preventDefault();
    const data = Object.fromEntries(new FormData(e.target));
    try {
      await fetchJSON(`${API}/admin/table/${table}/${id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data)
      });
      onSelectTable(table, document.querySelector('#tablesMenu button.active'));
    } catch (err) {
      alert("❌ Error al actualizar: " + err.message);
    }
  });
}

async function deleteRow(table, id) {
  if (!confirm("¿Seguro que deseas eliminar este registro?")) return;
  try {
    await fetchJSON(`${API}/admin/table/${table}/${id}`, { method: "DELETE" });
    onSelectTable(table, document.querySelector('#tablesMenu button.active'));
  } catch (err) {
    alert("❌ Error al eliminar: " + err.message);
  }
}

function viewRow(table, id) {
  alert(`Detalles del registro ${id} en ${table}`);
}

/* =========================
   REPORTES RESERVAS (PDF)
========================= */
async function generateReservationsReport() {
  const data = await fetchJSON(`${API}/admin/table/reservas`);
  if (!data.length) return alert("No hay reservas registradas");
  const { jsPDF } = window.jspdf;
  const doc = new jsPDF();
  const stamp = new Date().toISOString().slice(0,10);
  doc.text(`DentalAME - Reporte General de Reservas (${stamp})`, 14, 15);
  doc.autoTable({
    startY: 20,
    head: [["Paciente", "Doctor", "Especialidad", "Consultorio", "Fecha", "Hora", "Estado"]],
    body: data.map(r => [r.paciente, r.doctor, r.especialidad, r.consultorio, r.fecha, r.hora, r.estado]),
  });
  doc.save(`Reporte_DentalAME_${stamp}.pdf`);
}

async function generateReservationsReportByDate() {
  const fi = document.getElementById("fechaInicio").value;
  const ff = document.getElementById("fechaFin").value;
  if (!fi || !ff) return alert("Selecciona ambas fechas");
  const dataAll = await fetchJSON(`${API}/admin/table/reservas`);
  const data = dataAll.filter(r => new Date(r.fecha) >= new Date(fi) && new Date(r.fecha) <= new Date(ff));
  if (!data.length) return alert("No hay reservas en ese rango");
  const { jsPDF } = window.jspdf;
  const doc = new jsPDF();
  doc.text(`DentalAME - Reporte de Reservas (${fi} a ${ff})`, 14, 15);
  doc.autoTable({
    startY: 20,
    head: [["Paciente", "Doctor", "Especialidad", "Consultorio", "Fecha", "Hora", "Estado"]],
    body: data.map(r => [r.paciente, r.doctor, r.especialidad, r.consultorio, r.fecha, r.hora, r.estado]),
  });
  doc.save(`Reporte_DentalAME_${fi}_a_${ff}.pdf`);
}

/* =========================
   COMPROBANTE DE PAGO
========================= */
async function generatePaymentReceipt(id) {
  try {
    const pagos = await fetchJSON(`${API}/admin/table/pagos`);
    const pago = pagos.find(p => p.id === id);
    if (!pago) return alert("Pago no encontrado");

    const qrText = `DentalAME | Pago #${pago.id}
${pago.paciente || ""}
${pago.consultorio || ""}
${pago.fecha_pago || ""}
Monto: $${pago.monto || ""}`;

    const qrDiv = document.createElement("div");
    new QRCode(qrDiv, { text: qrText, width: 100, height: 100, correctLevel: QRCode.CorrectLevel.M });
    await new Promise(r => setTimeout(r, 300));
    const qrImg = qrDiv.querySelector("img");
    if (!qrImg) throw new Error("No se pudo generar el QR");
    const qrData = qrImg.src;

    const { jsPDF } = window.jspdf;
    const doc = new jsPDF();

    function drawReceipt(tipo, y) {
      doc.setFont("helvetica", "bold");
      doc.setFontSize(16);
      doc.text(`COMPROBANTE DE PAGO - ${tipo}`, 50, y);
      doc.setFont("helvetica", "normal");
      doc.setFontSize(12);
      doc.text(`Sr(es): ${pago.paciente || ""}`, 20, y + 20);
      doc.text(`Doctor: ${pago.doctor || ""}`, 20, y + 30);
      doc.text(`Consultorio: ${pago.consultorio || ""}`, 20, y + 40);
      doc.text(`Fecha: ${pago.fecha_pago || ""}`, 20, y + 50);
      doc.text(`Monto: $${pago.monto || ""}`, 20, y + 60);
      if (pago.descripcion) doc.text(`Descripción: ${pago.descripcion}`, 20, y + 70);
      doc.addImage(qrData, "PNG", 150, y + 10, 40, 40);
      doc.line(30, y + 95, 80, y + 95);
      doc.line(130, y + 95, 180, y + 95);
      doc.setFontSize(10);
      doc.text("Secretaria / Administrador", 30, y + 100);
      doc.text("Recibí conforme", 145, y + 100);
    }

    drawReceipt("ORIGINAL", 20);
    doc.line(10, 115, 200, 115);
    drawReceipt("COPIA", 130);
    doc.save(`comprobante_pago_${pago.id}.pdf`);
  } catch (err) {
    console.error("❌ Error generando comprobante:", err);
    alert("Error generando comprobante de pago.\n" + err.message);
  }
}

/* =========================
   Exponer funciones
========================= */
window.onSelectTable = onSelectTable;
window.newRow = newRow;
window.editRow = editRow;
window.deleteRow = deleteRow;
window.viewRow = viewRow;
window.generateReservationsReport = generateReservationsReport;
window.generateReservationsReportByDate = generateReservationsReportByDate;
window.generatePaymentReceipt = generatePaymentReceipt;

/* =========================
   INICIAR
========================= */
loadTablesMenu();
