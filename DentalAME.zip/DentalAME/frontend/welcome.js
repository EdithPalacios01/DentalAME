// menú móvil
const menuBtn = document.getElementById('menuBtn');
const mainNav = document.getElementById('mainNav');
menuBtn?.addEventListener('click', () => {
  mainNav.classList.toggle('open');
});

// fecha del dashboard y año footer
(function setDates(){
  const today = new Date();
  const label = today.toLocaleDateString('es-ES', { day:'2-digit', month:'short', year:'numeric' }).replace('.', '');
  document.getElementById('todayLabel').textContent = `Hoy: ${label}`;
  document.getElementById('year').textContent = today.getFullYear();
})();

// Animaciones al hacer scroll
const io = new IntersectionObserver(entries=>{
  entries.forEach(e=>{
    if(e.isIntersecting){ e.target.classList.add('visible'); io.unobserve(e.target); }
  });
},{threshold:.15});
document.querySelectorAll('.animate').forEach(el=>io.observe(el));

// Form demo (solo UI)
document.getElementById('demoForm')?.addEventListener('submit', (e)=>{
  const msg = document.getElementById('demoMsg');
  msg.textContent = '✅ ¡Gracias! Nos pondremos en contacto contigo pronto.';
  e.target.reset();
  setTimeout(()=> msg.textContent = '', 4000);
});

// Cerrar menú al navegar (móvil)
document.querySelectorAll('.nav a[href^="#"]').forEach(a=>{
  a.addEventListener('click', ()=> mainNav.classList.remove('open'));
});
